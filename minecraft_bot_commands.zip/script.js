// 👇 Put all your commands here
const commands = [
  "!help — Shows all commands",
  "!about — Info about the bot",
  "!ping — Checks if the bot is online"
];

// Find the <ul> element
const commandList = document.getElementById("commandList");

// Add each command to the list
commands.forEach(command => {
  const li = document.createElement("li");
  li.textContent = command;
  commandList.appendChild(li);
});
